// Functional Interface dùng để triển khai biểu thức Lambda tính chiết khấu
@FunctionalInterface
public interface Discountable {
    double applyDiscount(double price);
}