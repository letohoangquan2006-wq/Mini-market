// Ngoại lệ tùy chỉnh để bắt lỗi dữ liệu đầu vào của sản phẩm
public class InvalidProductException extends Exception {
    public InvalidProductException(String message) {
        super(message);
    }
}