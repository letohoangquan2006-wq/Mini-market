
    import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

    public class SupermarketGUI extends JFrame {
        private SupermarketService service = new SupermarketService();

        // Các thành phần giao diện
        private JTextField txtId = new JTextField(8);
        private JTextField txtName = new JTextField(12);
        private JTextField txtPrice = new JTextField(8);
        private JTextField txtQuantity = new JTextField(6);
        private JTextField txtExtra = new JTextField(6);
        private JComboBox<String> cbType = new JComboBox<>(new String[]{"Thực phẩm", "Điện tử"});
        private JTextField txtSearch = new JTextField(12);

        private DefaultTableModel tableModel;
        private JTable table;

        public SupermarketGUI() {
            setTitle("Hệ Thống Quản Lý Bán Hàng & Siêu Thị Mini");
            setSize(850, 520);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout(8, 8));

            // 1. Panel Nhập Dữ Liệu (North)
            JPanel inputPanel = new JPanel(new GridLayout(3, 4, 8, 8));
            inputPanel.setBorder(BorderFactory.createTitledBorder("Thông tin sản phẩm"));

            inputPanel.add(new JLabel("Mã SP:"));
            inputPanel.add(txtId);
            inputPanel.add(new JLabel("Tên SP:"));
            inputPanel.add(txtName);
            inputPanel.add(new JLabel("Giá gốc:"));
            inputPanel.add(txtPrice);
            inputPanel.add(new JLabel("Số lượng:"));
            inputPanel.add(txtQuantity);
            inputPanel.add(new JLabel("Loại SP:"));
            inputPanel.add(cbType);
            inputPanel.add(new JLabel("Tỉ lệ giảm / Phí BH:"));
            inputPanel.add(txtExtra);

            // 2. Bảng Hiển Thị Danh Sách (Center)
            tableModel = new DefaultTableModel(new Object[]{"Mã SP", "Tên SP", "Loại", "Giá Gốc", "Số Lượng", "Giá Cuối"}, 0);
            table = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(table);

            // 3. Panel Nút Chức Năng (South)
            JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            JButton btnAdd = new JButton("Thêm sản phẩm");
            JButton btnSearch = new JButton("Tìm kiếm");
            JButton btnReload = new JButton("Làm mới bảng");
            JButton btnPromo = new JButton("Áp mã VIP (Giảm thêm 5%)");

            actionPanel.add(btnAdd);
            actionPanel.add(new JLabel(" | Tìm theo tên:"));
            actionPanel.add(txtSearch);
            actionPanel.add(btnSearch);
            actionPanel.add(btnReload);
            actionPanel.add(btnPromo);

            add(inputPanel, BorderLayout.NORTH);
            add(scrollPane, BorderLayout.CENTER);
            add(actionPanel, BorderLayout.SOUTH);

            // BẮT SỰ KIỆN (Event Handling với Lambda)

            // Sự kiện: Thêm sản phẩm
            btnAdd.addActionListener(e -> handleAddProduct());

            // Sự kiện: Tìm kiếm bằng Stream/Lambda
            btnSearch.addActionListener(e -> {
                String keyword = txtSearch.getText();
                List<Product> result = service.searchByName(keyword);
                renderTable(result);
            });

            // Sự kiện: Làm mới bảng
            btnReload.addActionListener(e -> renderTable(service.getAllProducts()));

            // Sự kiện: Áp dụng Lambda Functional Interface trực tiếp
            btnPromo.addActionListener(e -> {
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(this, "Vui lòng chọn 1 sản phẩm trong bảng để tính giá VIP!");
                    return;
                }
                double finalPrice = (double) tableModel.getValueAt(selectedRow, 5);
                // Cú pháp Lambda biểu diễn phương thức applyDiscount
                Discountable vipPromo = p -> p * 0.95;
                double vipPrice = service.applyPromoCode(finalPrice, vipPromo);

                JOptionPane.showMessageDialog(this, "Giá sau khi áp mã VIP: " + String.format("%,.2f VNĐ", vipPrice));
            });
        }

        private void handleAddProduct() {
            try {
                String id = txtId.getText();
                String name = txtName.getText();
                double price = Double.parseDouble(txtPrice.getText());
                int qty = Integer.parseInt(txtQuantity.getText());
                double extra = Double.parseDouble(txtExtra.getText());
                String type = (String) cbType.getSelectedItem();

                Product product;
                if ("Thực phẩm".equals(type)) {
                    product = new FoodProduct(id, name, price, qty, extra);
                } else {
                    product = new ElectronicProduct(id, name, price, qty, extra);
                }

                service.addProduct(product);
                renderTable(service.getAllProducts());
                clearInputFields();
                JOptionPane.showMessageDialog(this, "Thêm sản phẩm thành công!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Lỗi định dạng: Giá, số lượng và phí phải là chữ số!", "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
            } catch (InvalidProductException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi nghiệp vụ", JOptionPane.WARNING_MESSAGE);
            }
        }

        private void renderTable(List<Product> list) {
            tableModel.setRowCount(0);
            for (Product p : list) {
                String typeStr = (p instanceof FoodProduct) ? "Thực phẩm" : "Điện tử";
                tableModel.addRow(new Object[]{
                        p.getId(),
                        p.getName(),
                        typeStr,
                        p.getOriginalPrice(),
                        p.getQuantity(),
                        p.calculateFinalPrice() // Thể hiện tính Đa hình lúc Runtime
                });
            }
        }

        private void clearInputFields() {
            txtId.setText("");
            txtName.setText("");
            txtPrice.setText("");
            txtQuantity.setText("");
            txtExtra.setText("");
            txtSearch.setText("");
        }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> {
                new SupermarketGUI().setVisible(true);
            });
        }
    }

