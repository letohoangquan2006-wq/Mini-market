
    // Kế thừa (Inheritance) từ Product
    public class FoodProduct extends Product {
        private double discountRate; // Ví dụ: 0.1 nghĩa là giảm 10%

        public FoodProduct(String id, String name, double originalPrice, int quantity, double discountRate) {
            super(id, name, originalPrice, quantity);
            this.discountRate = discountRate;
        }

        public double getDiscountRate() { return discountRate; }
        public void setDiscountRate(double discountRate) { this.discountRate = discountRate; }

        // Ghi đè phương thức: Thực phẩm được giảm giá theo hạn dùng
        @Override
        public double calculateFinalPrice() {
            return getOriginalPrice() * (1 - discountRate);
        }
    }

