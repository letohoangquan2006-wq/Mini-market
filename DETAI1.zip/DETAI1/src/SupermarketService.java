import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SupermarketService {
    // Sử dụng Collection API (List, ArrayList)
    private List<Product> productList = new ArrayList<>();

    // Thêm sản phẩm có kiểm tra tính hợp lệ (ném Ngoại lệ)
    public void addProduct(Product p) throws InvalidProductException {
        if (p.getId() == null || p.getId().trim().isEmpty()) {
            throw new InvalidProductException("Mã sản phẩm không được để trống!");
        }
        if (p.getOriginalPrice() < 0) {
            throw new InvalidProductException("Giá gốc không được âm!");
        }
        if (p.getQuantity() < 0) {
            throw new InvalidProductException("Số lượng không được nhỏ hơn 0!");
        }
        for (Product existing : productList) {
            if (existing.getId().equalsIgnoreCase(p.getId())) {
                throw new InvalidProductException("Mã sản phẩm đã tồn tại trong kho!");
            }
        }
        productList.add(p);
    }

    public List<Product> getAllProducts() {
        return productList;
    }

    // Sử dụng Stream API và Lambda Expression để lọc và tìm kiếm theo tên
    public List<Product> searchByName(String keyword) {
        return productList.stream()
                .filter(p -> p.getName().toLowerCase().contains(keyword.toLowerCase().trim()))
                .collect(Collectors.toList());
    }

    // Áp dụng khuyến mãi bằng Lambda Expression qua Functional Interface Discountable
    public double applyPromoCode(double price, Discountable discountRule) {
        return discountRule.applyDiscount(price);
    }

}