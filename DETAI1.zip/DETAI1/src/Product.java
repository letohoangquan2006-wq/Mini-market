    // Tính Đóng gói (Encapsulation): Các trường private, truy cập qua getter/setter
    public abstract class Product {
        private String id;
        private String name;
        private double originalPrice;
        private int quantity;

        public Product(String id, String name, double originalPrice, int quantity) {
            this.id = id;
            this.name = name;
            this.originalPrice = originalPrice;
            this.quantity = quantity;
        }

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public double getOriginalPrice() { return originalPrice; }
        public void setOriginalPrice(double originalPrice) { this.originalPrice = originalPrice; }

        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }

        // Phương thức trừu tượng thể hiện tính Đa hình (Polymorphism)
        public abstract double calculateFinalPrice();
    }



