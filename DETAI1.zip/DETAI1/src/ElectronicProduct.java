// Kế thừa (Inheritance) từ Product
public class ElectronicProduct extends Product {
    private double warrantyFee; // Phí bảo hành cộng thêm

    public ElectronicProduct(String id, String name, double originalPrice, int quantity, double warrantyFee) {
        super(id, name, originalPrice, quantity);
        this.warrantyFee = warrantyFee;
    }

    public double getWarrantyFee() { return warrantyFee; }
    public void setWarrantyFee(double warrantyFee) { this.warrantyFee = warrantyFee; }

    // Ghi đè phương thức: Đồ điện tử tính thêm phí bảo hành tiêu chuẩn
    @Override
    public double calculateFinalPrice() {
        return getOriginalPrice() + warrantyFee;
    }
}

